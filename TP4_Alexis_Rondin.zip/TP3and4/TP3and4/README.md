# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.1.6/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.1.6/maven-plugin/reference/html/#build-image)
* [Spring Web](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#web)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#data.sql.jpa-and-spring-data)
* [Validation](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#io.validation)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#using.devtools)
* [Thymeleaf](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#web.servlet.spring-mvc.template-engines)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)

### Réponses pour l'etape 6

• Faut-il une clé API pour appeler MeteoConcept ?
 Oui, l'accès à l'API MeteoConcept nécessite une clé API. Je dois créer un compte sur leur plateforme pour obtenir ma propre clé d'accès.

• Quelle URL appeler ?
L'URL pour accéder à l'API MeteoConcept est : `https://api.meteoconcept.com/api/forecast/daily/0?token={ma_clé_api}`.

• Quelle méthode HTTP utiliser ?
Pour récupérer les données, j'utilise la méthode HTTP GET pour obtenir les prévisions météorologiques.

• Comment passer les paramètres d'appels ?
Je peux transmettre les paramètres directement dans l'URL. Par exemple, je spécifie les coordonnées GPS nécessaires pour obtenir des prévisions pour un lieu spécifique.

• Où est l'information dont j'ai besoin dans la réponse :
• Pour afficher la température du lieu visé par les coordonnées GPS
 Je cherche la section "forecast" ou "temperature" dans la réponse JSON pour obtenir les données de température actuelle ou prévue.

• Pour afficher la prévision de météo du lieu visé par les coordonnées GP
Les détails météorologiques se trouvent dans la section "forecast" ou "weather". Je consulte cette section pour obtenir des informations sur les conditions météorologiques prévues.



Lien github: https://github.com/reezGREG/