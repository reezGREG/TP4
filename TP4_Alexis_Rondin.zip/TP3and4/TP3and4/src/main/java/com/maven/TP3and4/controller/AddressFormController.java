package com.maven.TP3and4.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AddressFormController {
    
    @GetMapping("/adresse")
    public String showAddressForm() {
        return "address_form";
    }
    
    @PostMapping("/weather")
    public String getWeather(@RequestParam("address") String address) {
        
        return "weather_results";
    }
}
