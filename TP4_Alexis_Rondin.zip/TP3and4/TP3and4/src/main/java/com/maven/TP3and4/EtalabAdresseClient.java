package com.maven.TP3and4;

import org.springframework.web.client.RestTemplate;

public class EtalabAdresseClient {

    private final String ETALAB_API_URL = "https://geo.api.gouv.fr/adresse";

    public void getAddressInfo(String address) {
        RestTemplate restTemplate = new RestTemplate();

        // Faire une requête GET vers l'API Adresse d'Etalab
        String apiUrl = ETALAB_API_URL + "?q=" + address; // Composez l'URL avec l'adresse
        String jsonResponse = restTemplate.getForObject(apiUrl, String.class);

        // Traitement reponse json
        System.out.println(jsonResponse);
    }
}
